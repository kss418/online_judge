#pragma once

#include "dto/auth_dto.hpp"
#include "dto/problem_dto.hpp"
#include "dto/user_dto.hpp"
#include "dto/user_statistics_dto.hpp"

#include <boost/json.hpp>

#include <cstdint>

namespace user_json_serializer{
    boost::json::object make_permission_object(
        std::int64_t user_id,
        std::int32_t permission_level
    );
    boost::json::object make_submission_ban_object(
        const user_dto::submission_ban& submission_ban_value
    );
    boost::json::object make_submission_ban_status_object(
        const user_dto::submission_ban_status& submission_ban_status_value
    );

    boost::json::object make_me_object(const auth_dto::identity& auth_identity_value);
    boost::json::object make_summary_object(const user_dto::summary& summary_value);
    boost::json::object make_public_list_object(
        const user_dto::list& user_values
    );

    boost::json::object make_submission_statistics_object(
        const user_statistics_dto::submission_statistics& statistics_value
    );
    boost::json::object make_solved_problem_list_object(
        const std::vector<problem_dto::summary>& solved_problem_values
    );
    boost::json::object make_wrong_problem_list_object(
        const std::vector<problem_dto::summary>& wrong_problem_values
    );

    boost::json::object make_list_object(
        const auth_dto::user_summary_list& user_summary_values
    );
}
