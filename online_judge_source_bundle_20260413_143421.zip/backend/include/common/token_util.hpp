#pragma once
#include "error/infra_error.hpp"

#include <chrono>
#include <cstddef>
#include <expected>
#include <string>
#include <string_view>

namespace token_util{
    inline constexpr std::size_t TOKEN_BYTE_LENGTH = 32;
    inline constexpr std::chrono::seconds TOKEN_TTL{std::chrono::hours{24 * 30}};

    struct issued_token{
        std::string token;
        std::string token_hash;
    };

    std::expected<std::string, infra_error> generate_token();
    std::expected<issued_token, infra_error> issue_token();
}
