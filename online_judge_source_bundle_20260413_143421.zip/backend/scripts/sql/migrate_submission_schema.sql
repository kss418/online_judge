BEGIN;

CREATE TABLE IF NOT EXISTS schema_migrations(
    version TEXT PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

DO $do$
BEGIN
    IF NOT EXISTS(
        SELECT 1
        FROM pg_type
        WHERE typname = 'submission_status'
    ) THEN
        CREATE TYPE submission_status AS ENUM(
            'queued',
            'judging',
            'accepted',
            'wrong_answer',
            'time_limit_exceeded',
            'memory_limit_exceeded',
            'runtime_error',
            'compile_error',
            'build_resource_exceeded',
            'output_exceeded',
            'infra_failure'
        );
    END IF;
END
$do$;

DO $do$
BEGIN
    IF NOT EXISTS(
        SELECT 1
        FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'users'
    ) THEN
        RAISE EXCEPTION 'auth_schema must be applied before submission_schema';
    END IF;

    IF NOT EXISTS(
        SELECT 1
        FROM information_schema.tables
        WHERE table_schema = 'public' AND table_name = 'problems'
    ) THEN
        RAISE EXCEPTION 'problem_schema must be applied before submission_schema';
    END IF;
END
$do$;

CREATE TABLE IF NOT EXISTS submissions(
    submission_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(user_id),
    problem_id BIGINT NOT NULL REFERENCES problems(problem_id),
    problem_version INTEGER NOT NULL,
    language TEXT NOT NULL,
    source_code TEXT NOT NULL,
    status submission_status NOT NULL DEFAULT 'queued',
    score SMALLINT,
    compile_output TEXT,
    judge_output TEXT,
    elapsed_ms BIGINT,
    max_rss_kb BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT submissions_score_range_check
        CHECK(score IS NULL OR (score >= 0 AND score <= 100)),
    CONSTRAINT submissions_elapsed_ms_check
        CHECK(elapsed_ms IS NULL OR elapsed_ms >= 0),
    CONSTRAINT submissions_max_rss_kb_check
        CHECK(max_rss_kb IS NULL OR max_rss_kb >= 0)
);

CREATE TABLE IF NOT EXISTS submission_status_history(
    history_id BIGSERIAL PRIMARY KEY,
    submission_id BIGINT NOT NULL REFERENCES submissions(submission_id) ON DELETE CASCADE,
    from_status submission_status,
    to_status submission_status NOT NULL,
    reason TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS submission_queue(
    queue_id BIGSERIAL PRIMARY KEY,
    submission_id BIGINT NOT NULL UNIQUE REFERENCES submissions(submission_id) ON DELETE CASCADE,
    priority SMALLINT NOT NULL DEFAULT 0,
    attempt_no INTEGER NOT NULL DEFAULT 0,
    lease_token TEXT,
    available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    leased_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT submission_queue_attempt_no_check CHECK(attempt_no >= 0)
);

CREATE TABLE IF NOT EXISTS judge_instances(
    instance_id TEXT PRIMARY KEY,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_heartbeat_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    configured_worker_count BIGINT NOT NULL DEFAULT 0,
    busy_worker_count BIGINT NOT NULL DEFAULT 0,
    snapshot_cache_hit_count BIGINT NOT NULL DEFAULT 0,
    snapshot_cache_miss_count BIGINT NOT NULL DEFAULT 0,
    last_sandbox_self_check_status TEXT,
    last_sandbox_self_check_at TIMESTAMPTZ,
    last_sandbox_self_check_message TEXT,
    CONSTRAINT judge_instances_configured_worker_count_check
        CHECK(configured_worker_count >= 0),
    CONSTRAINT judge_instances_busy_worker_count_check
        CHECK(busy_worker_count >= 0),
    CONSTRAINT judge_instances_snapshot_cache_hit_count_check
        CHECK(snapshot_cache_hit_count >= 0),
    CONSTRAINT judge_instances_snapshot_cache_miss_count_check
        CHECK(snapshot_cache_miss_count >= 0)
);

ALTER TABLE submissions
    ADD COLUMN IF NOT EXISTS problem_version INTEGER;

UPDATE submissions submission_table
SET problem_version = problem_table.version
FROM problems problem_table
WHERE
    problem_table.problem_id = submission_table.problem_id AND
    submission_table.problem_version IS NULL;

ALTER TABLE submissions
    ALTER COLUMN problem_version SET NOT NULL;

ALTER TABLE submission_queue
    ADD COLUMN IF NOT EXISTS attempt_no INTEGER NOT NULL DEFAULT 0;

ALTER TABLE submission_queue
    ADD COLUMN IF NOT EXISTS lease_token TEXT;

DO $do$
BEGIN
    IF EXISTS(
        SELECT 1
        FROM information_schema.columns
        WHERE
            table_schema = 'public' AND
            table_name = 'submission_queue' AND
            column_name = 'attempt_count'
    ) THEN
        EXECUTE
            'UPDATE submission_queue '
            'SET attempt_no = attempt_count '
            'WHERE attempt_no = 0 AND attempt_count <> 0';
        EXECUTE
            'ALTER TABLE submission_queue DROP COLUMN attempt_count';
    END IF;
END
$do$;

ALTER TABLE submission_queue
    DROP COLUMN IF EXISTS problem_version;

DO $do$
BEGIN
    IF NOT EXISTS(
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'submission_queue_attempt_no_check'
    ) THEN
        ALTER TABLE submission_queue
            ADD CONSTRAINT submission_queue_attempt_no_check
            CHECK(attempt_no >= 0);
    END IF;
END
$do$;

CREATE INDEX IF NOT EXISTS submissions_user_created_idx
    ON submissions(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS submissions_problem_created_idx
    ON submissions(problem_id, created_at DESC);

CREATE INDEX IF NOT EXISTS submission_status_history_submission_created_idx
    ON submission_status_history(submission_id, created_at DESC);

CREATE INDEX IF NOT EXISTS submission_queue_available_priority_created_idx
    ON submission_queue(available_at, priority DESC, created_at ASC);

CREATE INDEX IF NOT EXISTS submission_queue_leased_until_idx
    ON submission_queue(leased_until);

CREATE INDEX IF NOT EXISTS judge_instances_last_heartbeat_idx
    ON judge_instances(last_heartbeat_at DESC);

CREATE INDEX IF NOT EXISTS judge_instances_last_self_check_idx
    ON judge_instances(last_sandbox_self_check_at DESC);

INSERT INTO schema_migrations(version)
VALUES('submission_schema_v8')
ON CONFLICT(version) DO NOTHING;

COMMIT;
