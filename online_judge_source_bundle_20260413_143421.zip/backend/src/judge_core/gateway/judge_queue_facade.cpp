#include "judge_core/gateway/judge_queue_facade.hpp"

#include "db_service/submission_service.hpp"

#include <utility>

std::expected<judge_queue_facade, judge_error> judge_queue_facade::create(
    const db_connection_config& db_config
){
    auto lease_db_connection_exp = db_connection::create(db_config);
    if(!lease_db_connection_exp){
        return std::unexpected(judge_error{lease_db_connection_exp.error()});
    }

    auto queue_source_connection_exp = db_connection::create(db_config);
    if(!queue_source_connection_exp){
        return std::unexpected(judge_error{queue_source_connection_exp.error()});
    }

    auto submission_queue_source_exp = submission_queue_source::create(
        std::move(*queue_source_connection_exp)
    );
    if(!submission_queue_source_exp){
        return std::unexpected(judge_error{submission_queue_source_exp.error()});
    }

    return judge_queue_facade(
        std::move(*lease_db_connection_exp),
        std::move(*submission_queue_source_exp)
    );
}

judge_queue_facade::judge_queue_facade(
    db_connection lease_db_connection,
    submission_queue_source submission_queue_source_value
) :
    lease_db_connection_(std::move(lease_db_connection)),
    submission_queue_source_(std::move(submission_queue_source_value)){}

judge_queue_facade::judge_queue_facade(
    judge_queue_facade&& other
) noexcept = default;

judge_queue_facade& judge_queue_facade::operator=(
    judge_queue_facade&& other
) noexcept = default;

judge_queue_facade::~judge_queue_facade() = default;

std::expected<std::optional<submission_domain_dto::leased_submission>, judge_error>
judge_queue_facade::try_lease_next(std::chrono::seconds lease_duration){
    submission_internal_dto::lease_request lease_request_value;
    lease_request_value.lease_duration = lease_duration;

    auto leased_submission_opt_exp = submission_service::lease_submission(
        lease_db_connection_,
        lease_request_value
    );
    if(!leased_submission_opt_exp){
        return std::unexpected(judge_error{leased_submission_opt_exp.error()});
    }
    if(leased_submission_opt_exp->has_value()){
        return std::move(*leased_submission_opt_exp);
    }

    return std::optional<submission_domain_dto::leased_submission>{};
}

std::expected<void, judge_error> judge_queue_facade::wait_for_work(
    std::chrono::milliseconds notification_wait_timeout
){
    const auto wait_submission_notification_exp =
        submission_queue_source_.wait_submission_notification(
            notification_wait_timeout
        );
    if(!wait_submission_notification_exp){
        return std::unexpected(
            judge_error{wait_submission_notification_exp.error()}
        );
    }

    return {};
}
