#include "error/judge_error.hpp"

#include "error/db_error.hpp"
#include "error/infra_error.hpp"
#include "error/io_error.hpp"
#include "error/sandbox_error.hpp"
#include "error/submission_event_error.hpp"

#include <array>
#include <cstddef>
#include <string_view>
#include <utility>

namespace{
    struct judge_error_spec{
        std::string_view default_message;
    };

    constexpr judge_error_spec unknown_judge_error_spec{
        "unknown judge error"
    };

    constexpr std::array<judge_error_spec, 5> judge_error_specs{{
        {"validation error"},
        {"not found"},
        {"conflict"},
        {"unavailable"},
        {"internal"},
    }};

    const judge_error_spec& describe_judge_error(judge_error_code code){
        const auto index = static_cast<std::size_t>(code);
        if(index >= judge_error_specs.size()){
            return unknown_judge_error_spec;
        }

        return judge_error_specs[index];
    }

    judge_error_code map_db_error_code(const db_error& ec){
        switch(ec.code){
            case db_error_code::invalid_argument:
            case db_error_code::constraint_violation:
                return judge_error_code::validation_error;
            case db_error_code::unique_violation:
                return judge_error_code::conflict;
            case db_error_code::invalid_connection:
            case db_error_code::interrupted:
            case db_error_code::broken_connection:
            case db_error_code::serialization_failure:
            case db_error_code::deadlock_detected:
            case db_error_code::unavailable:
                return judge_error_code::unavailable;
            case db_error_code::internal:
                return judge_error_code::internal;
        }

        return judge_error_code::internal;
    }

    judge_error_code map_infra_error_code(const infra_error& ec){
        switch(ec.code){
            case infra_error_code::invalid_argument:
                return judge_error_code::validation_error;
            case infra_error_code::not_found:
                return judge_error_code::not_found;
            case infra_error_code::conflict:
                return judge_error_code::conflict;
            case infra_error_code::unavailable:
                return judge_error_code::unavailable;
            case infra_error_code::permission_denied:
            case infra_error_code::internal:
                return judge_error_code::internal;
        }

        return judge_error_code::internal;
    }

    judge_error_code map_io_error_code(const io_error& ec){
        switch(ec.code){
            case io_error_code::invalid_argument:
                return judge_error_code::validation_error;
            case io_error_code::not_found:
                return judge_error_code::not_found;
            case io_error_code::conflict:
                return judge_error_code::conflict;
            case io_error_code::unavailable:
                return judge_error_code::unavailable;
            case io_error_code::permission_denied:
            case io_error_code::internal:
                return judge_error_code::internal;
        }

        return judge_error_code::internal;
    }

    judge_error_code map_sandbox_error_code(const sandbox_error& ec){
        switch(ec.code){
            case sandbox_error_code::invalid_argument:
                return judge_error_code::validation_error;
            case sandbox_error_code::unavailable:
                return judge_error_code::unavailable;
            case sandbox_error_code::invalid_configuration:
            case sandbox_error_code::unsupported:
            case sandbox_error_code::internal:
                return judge_error_code::internal;
        }

        return judge_error_code::internal;
    }

    judge_error_code map_submission_event_error_code(const submission_event_error& ec){
        switch(ec.code){
            case submission_event_error_code::invalid_argument:
                return judge_error_code::validation_error;
            case submission_event_error_code::unavailable:
                return judge_error_code::unavailable;
            case submission_event_error_code::internal:
                return judge_error_code::internal;
        }

        return judge_error_code::internal;
    }

    judge_error_code map_service_error_code(const service_error& ec){
        switch(ec.code){
            case service_error_code::validation_error:
                return judge_error_code::validation_error;
            case service_error_code::not_found:
                return judge_error_code::not_found;
            case service_error_code::conflict:
                return judge_error_code::conflict;
            case service_error_code::unavailable:
                return judge_error_code::unavailable;
            case service_error_code::unauthorized:
            case service_error_code::forbidden:
            case service_error_code::internal:
                return judge_error_code::internal;
        }

        return judge_error_code::internal;
    }

}

judge_error::judge_error(
    judge_error_code code_value,
    std::string message_value
):
    code(code_value),
    message(
        message_value.empty()
            ? std::string{describe_judge_error(code_value).default_message}
            : std::move(message_value)
    ){}

judge_error::judge_error(const db_error& ec) :
    judge_error(map_db_error_code(ec), ec.message){}

judge_error::judge_error(const service_error& ec) :
    judge_error(map_service_error_code(ec), ec.message){}

judge_error::judge_error(const infra_error& ec) :
    judge_error(map_infra_error_code(ec), ec.message){}

judge_error::judge_error(const io_error& ec) :
    judge_error(map_io_error_code(ec), ec.message){}

judge_error::judge_error(const sandbox_error& ec) :
    judge_error(map_sandbox_error_code(ec), ec.message){}

judge_error::judge_error(const submission_event_error& ec) :
    judge_error(map_submission_event_error_code(ec), ec.message){}

bool judge_error::operator==(const judge_error& other) const{
    return code == other.code;
}

const judge_error judge_error::validation_error{
    judge_error_code::validation_error
};
const judge_error judge_error::not_found{
    judge_error_code::not_found
};
const judge_error judge_error::conflict{
    judge_error_code::conflict
};
const judge_error judge_error::unavailable{
    judge_error_code::unavailable
};
const judge_error judge_error::internal{
    judge_error_code::internal
};

std::string to_string(judge_error_code ec){
    return std::string{describe_judge_error(ec).default_message};
}

std::string to_string(const judge_error& ec){
    return ec.message;
}
